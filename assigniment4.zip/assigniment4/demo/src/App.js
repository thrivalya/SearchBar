import React from 'react'
import CardDeatils from './components/CardDeatils'
function App() {
  return (
    <div>
      <CardDeatils/>
    </div>
  )
}

export default App
