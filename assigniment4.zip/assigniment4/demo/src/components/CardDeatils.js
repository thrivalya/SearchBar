import React, { useState } from 'react';
import './card.css';
import DataDetails from './DataDetails';

function CardDetails() {
    const products = [
        {
          id: 'rec43w3ipXvP28vog',
          title: 'high-back bench',
          company: 'ikea',
          image: 'https://course-api.com/images/store/product-1.jpeg',
          price: 9.99,
        },
        {
          id: 'rec4f2RIftFCb7aHh',
          title: 'albany table',
          company: 'marcos',
          image: 'https://course-api.com/images/store/product-2.jpeg',
          price: 79.99,
        },
        {
          id: 'rec8kkCmSiMkbkiko',
          title: 'accent chair',
          company: 'caressa',
          image: 'https://course-api.com/images/store/product-3.jpeg',
          price: 25.99,
        },
        {
          id: 'recBohCqQsot4Q4II',
          title: 'wooden table',
          company: 'caressa',
          image: 'https://course-api.com/images/store/product-4.jpeg',
      
          price: 45.99,
        },
        {
          id: 'recDG1JRZnbpRHpoy',
          title: 'dining table',
          company: 'caressa',
          image: 'https://course-api.com/images/store/product-5.jpeg',
      
          price: 6.99,
        },
        {
          id: 'recNWGyP7kjFhSqw3',
          title: 'sofa set',
          company: 'liddy',
          image: 'https://course-api.com/images/store/product-6.jpeg',
          price: 69.99,
        },
        {
          id: 'recZEougL5bbY4AEx',
          title: 'modern bookshelf',
          company: 'marcos',
          image: 'https://course-api.com/images/store/product-7.jpeg',
          price: 8.99,
        },
        {
          id: 'recjMK1jgTb2ld7sv',
          title: 'emperor bed',
          company: 'liddy',
          image: 'https://course-api.com/images/store/product-8.jpeg',
          price: 21.99,
        },
        {
          id: 'recmg2a1ctaEJNZhu',
          title: 'utopia sofa',
          company: 'marcos',
          image: 'https://course-api.com/images/store/product-9.jpeg',
          price: 39.95,
        },
        {
          id: 'recvKMNR3YFw0bEt3',
          title: 'entertainment center',
          company: 'liddy',
          image: 'https://course-api.com/images/store/product-10.jpeg',
          price: 29.98,
        },
        {
          id: 'recxaXFy5IW539sgM',
          title: 'albany sectional',
          company: 'ikea',
          image: 'https://course-api.com/images/store/product-11.jpeg',
          price: 10.99,
        },
        {
          id: 'recyqtRglGNGtO4Q5',
          title: 'leather sofa',
          company: 'liddy',
          image: 'https://course-api.com/images/store/product-12.jpeg',
          price: 9.99,
        },
      ];
      
      const [searchQuery, setSearchQuery] = useState('');

  const [selectedCompany, setSelectedCompany] = useState('all');

  const handleCompanyClick = (companyName) => {
    setSelectedCompany(companyName);
  };
  const handleSearch = (event) => {
    setSearchQuery(event.target.value.toLowerCase());
  };
  return (
    <div className='box'>
      <div className='navelements'>
      <input
          type='search'
          placeholder='Search by title...'
          value={searchQuery}
          onChange={handleSearch}
        />        <p className='company'>Company</p>
        <p onClick={() => handleCompanyClick('all')}>All</p>
        <p onClick={() => handleCompanyClick('ikea')}>Ikea</p>
        <p onClick={() => handleCompanyClick('marcos')}>Marcos</p>
        <p onClick={() => handleCompanyClick('caressa')}>Caressa</p>
        <p onClick={() => handleCompanyClick('liddy')}>Liddy</p>

      </div>
      <div className='page'>
        {products
          .filter(
            (product) =>
              (selectedCompany === 'all' || product.company.toLowerCase() === selectedCompany) &&
              product.title.toLowerCase().includes(searchQuery)
          )
          .map((data) => (
            <DataDetails
              key={data.id}
              image={data.image}
              title={data.title}
              price={data.price}
            />
          ))}
      </div>
    </div>
  );
}

export default CardDetails;
