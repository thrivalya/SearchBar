import React from 'react'

function DataDetails(props) {
  return (
    <div className='carditems'>
      <img src={props.image}/>
      <p>{props.title}</p>
      <p>{props.price}</p>
    </div>
  )
}

export default DataDetails
